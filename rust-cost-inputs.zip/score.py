#!/usr/bin/env python3
"""Score preserved answers without inferring missing calls from graph adjacency."""
import json
import math
import os
from pathlib import Path
import random
import re
from typing import Any


def wilson(k, n):
    if not n:
        return None
    z = 1.959963984540054
    d = 1 + z * z / n
    c = (k / n + z * z / (2 * n)) / d
    r = z * math.sqrt(k * (n - k) / n ** 3 + z * z / (4 * n * n)) / d
    return [max(0, c - r), min(1, c + r)]


def norm(file, repo):
    file = file.replace("\\", "/")
    marker = "/corpus/" + repo + "/"
    return file.split(marker, 1)[-1] if marker in file else file.removeprefix("./")


def owner(definitions, file, line):
    pool = [d for d in definitions if d["file"] == file and d["range"]["start"]["line"] + 1 <= line <= d["range"]["end"]["line"] + 1]
    return min(pool, key=lambda d: d["range"]["end"]["line"] - d["range"]["start"]["line"])["id"] if pool else file + ":<module>"


def emitted(row, tool, definitions, repo, call_owners=None):
    edges = []
    uncertain = 0
    unresolved = 0
    if tool == "aft":
        response = row.get("response", {})
        unresolved = response.get("unresolved_call_sites", 0)
        complete = bool(response.get("success")) and not response.get("truncated") and not response.get("hub_summary") and response.get("complete", True)
        for group in response.get("callers", []):
            file = norm(group["file"], repo)
            for e in group["callers"]:
                if e.get("relation") in ("callback_ref", "callback_reference", "indirect_call"):
                    continue
                approx = e.get("approximate", False) or e.get("resolved_by") == "name_match"
                uncertain += bool(approx)
                canonical_owner = (call_owners or {}).get((file, e["line"]), owner(definitions, file, e["line"]))
                edges.append({"caller": canonical_owner, "file": file, "line": e["line"], "certain": not approx, "raw": e})
    else:
        complete = row.get("complete", False)
        for e in row.get("calls", []):
            n = e["caller_node"]
            file = norm(n.get("source_file", ""), repo)
            loc = re.search(r"\d+", str(n.get("source_location", "")))
            definition_line = int(loc.group()) if loc else 0
            edge = e["edge"]
            site = re.search(r"\d+", str(edge.get("source_location", "")))
            certain = edge.get("confidence") == "EXTRACTED"
            uncertain += not certain
            edges.append({"caller": owner(definitions, file, definition_line), "file": file, "line": int(site.group()) if site else None, "certain": certain, "raw": e})
    return edges, complete, uncertain, unresolved


def compare(truth, edges, pairs_only=False):
    no_line = {e["caller"] for e in edges if e["line"] is None}
    def key(e):
        return (e["caller"], None if pairs_only or e["caller"] in no_line else e["line"])
    true = {key(e) for e in truth}
    predicted = {key(e) for e in edges}
    return true & predicted, predicted - true, true - predicted


def main():
    base = Path.cwd() / "target/graphify-study/raw"
    plan = json.loads((base / "plan.json").read_text())
    buckets = {}
    judgments = []
    coverage = []
    for repo in plan["repositories"]:
        name = repo["name"]
        path = base / (name + "-oracle.json")
        if not path.exists():
            coverage.append({"repository": name, "status": "no_oracle_file"})
            continue
        oracle = json.loads(path.read_text())
        call_owners = {(c["file"], c["line"]): c["caller"] for c in oracle.get("python_call_owners", [])}
        selected = {d["id"] for d in oracle.get("samples", [])}
        records = {r["target"]["id"]: r for r in oracle.get("oracle_sets", []) if r["target"]["id"] in selected and r["complete"]}
        for tool in ("aft", "graphify"):
            path = base / (name + "-" + tool + ".json")
            answers = json.loads(path.read_text()) if path.exists() else {}
            n_complete = 0
            uncertainty: dict[str, Any] = {"uncertain_emitted_edges": 0, "targets_with_unresolved_note": 0, "max_reported_unresolved_sites": 0, "confidence_labels": {}}
            for row in answers.get("samples", []):
                target = row["target"]
                record = records.get(target["id"])
                if record is None:
                    continue
                edges, complete, uncertain, unresolved = emitted(row, tool, oracle["definitions"], name, call_owners)
                n_complete += bool(complete)
                uncertainty["uncertain_emitted_edges"] += uncertain
                uncertainty["targets_with_unresolved_note"] += bool(unresolved)
                uncertainty["max_reported_unresolved_sites"] = max(unresolved, uncertainty["max_reported_unresolved_sites"])
                for edge in edges:
                    label = ("name_match" if not edge["certain"] else "unmarked_or_type_resolved") if tool == "aft" else edge["raw"]["edge"].get("confidence", "missing")
                    uncertainty["confidence_labels"][label] = uncertainty["confidence_labels"].get(label, 0) + 1
                for mode in ("all", "certain"):
                    used = edges if mode == "all" else [e for e in edges if e["certain"]]
                    for representation in ("mixed_sites", "caller_pairs"):
                        tp, fp, fn = compare(record["calls"], used, representation == "caller_pairs")
                        for stratum in ["all", *target.get("strata", [])]:
                            key = (repo["language"], tool, mode, representation, stratum)
                            b = buckets.setdefault(key, {"tp": 0, "fp": 0, "fn": 0, "complete_targets": 0, "censored_targets": 0, "observed_tp": 0, "observed_fp": 0, "observed_fn": 0})
                            b["observed_tp"] += len(tp)
                            b["observed_fp"] += len(fp)
                            b["observed_fn"] += len(fn)
                            if complete:
                                b["tp"] += len(tp)
                                b["fp"] += len(fp)
                                b["fn"] += len(fn)
                                b["complete_targets"] += 1
                            else:
                                b["censored_targets"] += 1
                        if mode == "all" and representation == "caller_pairs":
                            for verdict, items in [("tp", tp), ("fp", fp), ("fn", fn)]:
                                for item in sorted(items):
                                    judgments.append({"repository": name, "language": repo["language"], "tool": tool, "target": target, "caller": item[0], "line": item[1], "oracle_verdict": verdict, "complete_tool_answer": complete,
                                                      "oracle_calls": [c for c in record["calls"] if c["caller"] == item[0]],
                                                      "tool_calls": [e for e in used if e["caller"] == item[0]]})
            coverage.append({"repository": name, "tool": tool, "selected_targets": len(selected), "valid_oracles": len(records), "answers": len(answers.get("samples", [])), "complete_answers": n_complete, "error": answers.get("error"), **uncertainty})
    rows = []
    for key, b in sorted(buckets.items()):
        tp, fp, fn = b["tp"], b["fp"], b["fn"]
        rows.append(dict(zip(["language", "tool", "mode", "representation", "stratum"], key), **b,
                         precision=tp / (tp + fp) if tp + fp else None,
                         recall=tp / (tp + fn) if tp + fn else None,
                         precision_ci95=wilson(tp, tp + fp), recall_ci95=wilson(tp, tp + fn),
                         observed_precision=b["observed_tp"] / (b["observed_tp"] + b["observed_fp"]) if b["observed_tp"] + b["observed_fp"] else None,
                         observed_recall=b["observed_tp"] / (b["observed_tp"] + b["observed_fn"]) if b["observed_tp"] + b["observed_fn"] else None,
                         observed_precision_ci95=wilson(b["observed_tp"], b["observed_tp"] + b["observed_fp"]),
                         observed_recall_ci95=wilson(b["observed_tp"], b["observed_tp"] + b["observed_fn"])))
    (base / "scores.json").write_text(json.dumps({"rows": rows, "coverage": coverage, "unmeasured_strata": ["dispatch", "alias_or_reexport"]}, indent=2))
    (base / "per-edge-judgments.json").write_text(json.dumps(judgments, indent=2))
    if os.environ.get("PRESERVE_AUDIT"):
        print(json.dumps({"score_rows": len(rows), "edge_judgments": len(judgments), "coverage": coverage, "audit": "preserved original random disagreement sample"}, indent=2))
        return
    audits = []
    for index, language in enumerate(["python", "typescript", "go", "rust"]):
        pool = [j for j in judgments if j["language"] == language and j["oracle_verdict"] != "tp"]
        rng = random.Random(20261001 + index)
        chosen = []
        cells = {}
        for tool in ("aft", "graphify"):
            for verdict in ("fp", "fn"):
                cell = [j for j in pool if j["tool"] == tool and j["oracle_verdict"] == verdict]
                cells[(tool, verdict)] = (len(cell), min(6, len(cell)))
                chosen.extend(rng.sample(cell, min(6, len(cell))))
        remainder = [j for j in pool if j not in chosen]
        fill = min(max(0, 25 - len(chosen)), len(remainder))
        chosen.extend(rng.sample(remainder, fill))
        for j in chosen:
            n, k = cells[(j["tool"], j["oracle_verdict"])]
            probability = k / n + (n - k) / n * fill / len(remainder) if remainder else 1.0
            audits.append(dict(j, audit_status="not_audited", oracle_error=None, rationale=None,
                               inclusion_probability=probability, audit_cell_population=n))
    (base / "audit-sample.json").write_text(json.dumps(audits, indent=2))
    print(json.dumps({"score_rows": len(rows), "edge_judgments": len(judgments), "audit_candidates": len(audits), "coverage": coverage}, indent=2))


if __name__ == "__main__":
    main()
