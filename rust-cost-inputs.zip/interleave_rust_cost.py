#!/usr/bin/env python3
"""Interleave fresh-state cold sessions without executing corpus code."""
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import zipfile

BASE = Path.cwd() / "target/rust-resolver-study"
DRIVER = BASE / "driver"

def main():
    binaries = {"base": BASE / "aft-main-final", "changed": BASE / "aft-changed-final"}
    for binary in binaries.values():
        if not binary.is_file():
            raise RuntimeError("Paired binary artifact missing: " + str(binary))
    runs = []
    phase = sys.argv[1] if len(sys.argv) > 1 else "cost-before"
    for round_index in range(1, 4):
        modes = [False, True] if round_index != 2 else [True, False]
        for views in modes:
            for source in ["base", "changed"]:
                label = f"{phase}-r{round_index}-{source}-{'on' if views else 'off'}"
                args = [sys.executable, str(DRIVER / "rerun_rust_resolver.py"), label, str(binaries[source]), "--perf"]
                if views:
                    args.append("--views")
                env = dict(os.environ, AFT_VIEW_PROFILE="1")
                print("RUN", label, flush=True)
                with (BASE / (label + ".log")).open("w") as log:
                    subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
                metric = json.loads((BASE / (label + "-metrics.json")).read_text())
                metric.update(round=round_index, source=source, cpu_s=metric["user_cpu_s"] + metric["system_cpu_s"])
                runs.append(metric)
                print(json.dumps(metric), flush=True)
    summary = []
    for views in [False, True]:
        for source in ["base", "changed"]:
            group = [r for r in runs if r["views"] == views and r["source"] == source]
            row = {"views": views, "source": source}
            for field in ["cold_wall_s", "cpu_s", "peak_rss_kib"]:
                values = [run[field] for run in group]
                row[field] = {"median": statistics.median(values), "min": min(values), "max": max(values), "values": values}
            summary.append(row)
    (BASE / (phase + "-summary.json")).write_text(json.dumps({"runs": runs, "summary": summary}, indent=2))
    print(json.dumps(summary, indent=2), flush=True)

if __name__ == "__main__":
    phase = sys.argv[1] if len(sys.argv) > 1 else "cost-before"
    try:
        main()
    finally:
        with zipfile.ZipFile(Path.cwd() / "target" / (phase + "-results.zip"), "w", zipfile.ZIP_DEFLATED) as out:
            for path in BASE.glob(phase + "*"):
                if path.is_file():
                    out.write(path, path.name)
                elif path.is_dir():
                    for child in path.rglob("*"):
                        if child.is_file():
                            out.write(child, str(child.relative_to(BASE)))
