#!/usr/bin/env python3
"""Read the original exited AFT stores without changing the frozen study inputs."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import platform
import sqlite3
from typing import Any

BASE = Path.cwd() / "target/graphify-study"
RAW = BASE / "raw"
OUT = BASE / "store-followup"
EXPECTED_BINARY = "b8ec5f38aba56ad8e64affddcd558a72333ff6e6fa18ae096b2732e74b4dcffb"

# This is direct_callers_for_tuple's unbounded join, restricted to actual calls.
# Callback values are excluded just as they were in the frozen public scoring.
CALLER_SQL = """
SELECT e.*, r.status AS ref_status, r.byte_start, r.byte_end,
       r.full_ref, r.short_name, r.line AS ref_line,
       src.file_path AS caller_file, src.scoped_name AS caller_symbol,
       src.start_line AS caller_start_line, src.end_line AS caller_end_line,
       src.is_test AS caller_is_test
FROM edges e
JOIN refs r ON r.ref_id=e.ref_id
JOIN nodes src ON src.id=e.source_node
JOIN files src_file ON src_file.path=src.file_path
WHERE e.kind='call' AND e.target_file=? AND e.target_symbol=?
ORDER BY e.source_node, r.byte_start, r.line, r.ref_id
"""


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def assert_study_aft_exited():
    active = []
    for file in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            exe = file.read_bytes().split(b"\0", 1)[0].decode(errors="replace")
            if exe == str(BASE / "aft"):
                active.append(file.parent.name)
        except OSError:
            pass
    if active:
        raise RuntimeError("Refusing a SQLite handle while study AFT is alive: " + repr(active))


def publication(repository):
    root = BASE / "state" / repository / "callgraph"
    pointers = sorted(f for f in root.glob("*/*.current") if f.is_file())
    if len(pointers) != 1:
        raise RuntimeError("Expected one original publication pointer: " + repr(pointers))
    pointer = pointers[0]
    filename = pointer.read_text().strip()
    if Path(filename).name != filename or not filename.endswith(".sqlite"):
        raise RuntimeError("Invalid publication filename")
    path = pointer.parent / filename
    if not path.is_file() or path.is_symlink():
        raise RuntimeError("Published SQLite file is absent or a symlink")
    return path, pointer


@contextlib.contextmanager
def closed_store(repository):
    assert_study_aft_exited()
    path, pointer = publication(repository)
    wal = Path(str(path) + "-wal")
    wal_size = wal.stat().st_size if wal.exists() else 0
    # immutable avoids even shared-memory setup when the exited store has no WAL.
    uri = path.as_uri() + "?mode=ro" + ("&immutable=1" if wal_size == 0 else "")
    connection = sqlite3.connect(uri)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    try:
        yield connection, path, pointer
    finally:
        connection.close()


def name_of(target):
    return target["name"].rsplit(".", 1)[-1].split("(")[0]


def utf8_column(line, utf16_column):
    prefix = line.encode("utf-16-le")[:utf16_column * 2].decode("utf-16-le")
    return len(prefix.encode("utf-8"))


def leading_declaration_line(lines, start):
    line = start - 1
    while line >= 0:
        text = lines[line].strip()
        if not text or text.startswith("//") or text.startswith("# "):
            line -= 1
        elif text.endswith("*/"):
            while line >= 0 and "/*" not in lines[line]:
                line -= 1
            line -= 1
        else:
            break
    return line + 1


def bind_target(connection, target, source, public_response=None) -> dict[str, Any]:
    name = name_of(target)
    candidates = [dict(r) for r in connection.execute(
        "SELECT * FROM nodes WHERE file_path=? AND (name=? OR scoped_name=?) ORDER BY start_line,start_col,end_line,end_col,id",
        (target["file"], name, name))]
    p = target["selection"]["start"]
    lines = source.decode(errors="replace").splitlines()
    column = utf8_column(lines[p["line"]], p["character"]) if p["line"] < len(lines) else p["character"]
    point = (p["line"], column)
    covering = [n for n in candidates if (n["start_line"], n["start_col"]) <= point <= (n["end_line"], n["end_col"])]
    if covering:
        minimum = min((n["end_line"] - n["start_line"], n["end_col"] - n["start_col"]) for n in covering)
        covering = [n for n in covering if (n["end_line"] - n["start_line"], n["end_col"] - n["start_col"]) == minimum]
    else:
        # Legacy rows can anchor a name-sized range at a leading doc/decorator line.
        earliest = leading_declaration_line(lines, target["range"]["start"]["line"])
        covering = [n for n in candidates if earliest <= n["start_line"] <= p["line"]]
    scopes = sorted({n["scoped_name"] for n in covering})
    identity_status = "bound" if len(scopes) == 1 else "missing" if not covering else "ambiguous"
    request_nodes = []
    if public_response and public_response.get("success") and public_response.get("symbol"):
        request_nodes = [dict(r) for r in connection.execute(
            "SELECT * FROM nodes WHERE file_path=? AND scoped_name=? ORDER BY start_line,start_col,id",
            (public_response.get("file", target["file"]), public_response["symbol"]))]
    if request_nodes:
        # Preserve the exact tuple the frozen public query actually addressed.
        scope = request_nodes[0]["scoped_name"]
        return {"status": "bound", "definition_identity": identity_status, "candidates": candidates,
                "selected_nodes": covering if scopes == [scope] else [], "tuple_nodes": request_nodes,
                "request_tuple_fallback": scopes != [scope], "tuples": [[request_nodes[0]["file_path"], scope]]}
    if len(scopes) != 1:
        return {"status": identity_status, "definition_identity": identity_status, "candidates": candidates, "selected_nodes": [], "tuples": []}
    scope = scopes[0]
    tuple_nodes = [dict(r) for r in connection.execute(
        "SELECT * FROM nodes WHERE file_path=? AND scoped_name=? ORDER BY start_line,start_col,id", (target["file"], scope))]
    return {"status": "bound", "definition_identity": identity_status, "candidates": candidates, "selected_nodes": covering,
            "tuple_nodes": tuple_nodes, "tuples": [[target["file"], scope]]}


def as_public_shape(target, edges) -> dict[str, Any]:
    groups = {}
    for edge in edges:
        entry = {"symbol": edge["caller_symbol"], "line": edge["line"],
                 "approximate": edge["provenance"] == "name_match", "resolved_by": edge["provenance"]}
        groups.setdefault(edge["caller_file"], []).append(entry)
    return {"target": target, "response": {"success": True, "complete": True,
            "callers": [{"file": file, "callers": calls} for file, calls in sorted(groups.items())]}}


def evidence_for_calls(connection, oracle_record):
    # Call/construction/macro ref lines are one-based, like displayed edge lines.
    result = []
    seen = set()
    for call in oracle_record["calls"]:
        key = call["file"], call["line"]
        if key in seen:
            continue
        seen.add(key)
        refs = [dict(r) for r in connection.execute(
            "SELECT * FROM refs WHERE caller_file=? AND line=? AND kind IN ('call','construction','macro_body_call','macro_mention') ORDER BY byte_start,ref_id",
            (call["file"], call["line"]))]
        edges = [dict(r) for r in connection.execute(
            "SELECT e.* FROM refs r JOIN edges e ON e.ref_id=r.ref_id WHERE r.caller_file=? AND r.line=? ORDER BY r.byte_start,e.edge_id",
            (call["file"], call["line"]))]
        result.append({"file": key[0], "line": key[1], "refs": refs, "edges_at_site": edges})
    return result


def verify_inputs():
    if platform.system() != "Linux":
        raise RuntimeError("Store measurement is Linux-only")
    identity = json.loads(os.environ["FROZEN_STORE_INPUTS"])
    if sha256(BASE / "aft") != EXPECTED_BINARY or identity["binary_sha256"] != EXPECTED_BINARY:
        raise RuntimeError("The original measured release binary changed")
    verified = {}
    for name, expected in identity["files"].items():
        actual = sha256(RAW / name)
        if actual != expected["sha256"]:
            raise RuntimeError("Frozen study input changed: " + name)
        verified[name] = actual
    return verified


def main():
    verified = verify_inputs()
    OUT.mkdir(parents=True, exist_ok=True)
    plan = json.loads((RAW / "plan.json").read_text())
    run: dict[str, Any] = {"binary_sha256": EXPECTED_BINARY, "frozen_inputs": verified,
                           "affinity": sorted(getattr(os, "sched_getaffinity")(0)), "platform": platform.platform(),
                           "sql": CALLER_SQL, "repositories": []}
    for repo in plan["repositories"]:
        name = repo["name"]
        oracle = json.loads((RAW / (name + "-oracle.json")).read_text())
        selected = {d["id"]: d for d in oracle["samples"]}
        truth = {r["target"]["id"]: r for r in oracle["oracle_sets"] if r["target"]["id"] in selected and r["complete"]}
        public = {r["target"]["id"]: r["response"] for r in json.loads((RAW / (name + "-aft.json")).read_text())["samples"]}
        if len(selected) != 150 or len(truth) != 150:
            raise RuntimeError("Frozen sample/oracle coverage changed for " + name)
        rows = []
        with closed_store(name) as (connection, path, pointer):
            before = sha256(path)
            metadata = dict(connection.execute("SELECT k,v FROM meta"))
            if metadata.get("ready") != "1" or metadata.get("staged_build_phase") != "ready":
                raise RuntimeError("Original store is not ready: " + name)
            schema = {r["name"]: r["sql"] for r in connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table'")}
            for target in selected.values():
                source = (BASE / "corpus" / name / target["file"]).read_bytes()
                binding = bind_target(connection, target, source, public[target["id"]])
                edges = []
                for file, scoped_name in binding["tuples"]:
                    edges.extend(dict(r) for r in connection.execute(CALLER_SQL, (file, scoped_name)))
                selected_ids = {n["id"] for n in binding["selected_nodes"]}
                positional = [e for e in edges if e["target_node"] in selected_ids]
                rows.append({"target": target, "binding": binding, "edges": edges,
                             "answer": as_public_shape(target, edges), "positional_answer": as_public_shape(target, positional),
                             "oracle_site_evidence": evidence_for_calls(connection, truth[target["id"]])})
            after = sha256(path)
            if before != after:
                raise RuntimeError("Read-only extraction changed or raced the store: " + name)
            identity = {"repository": name, "path": str(path.relative_to(BASE)), "generation": pointer.read_text().strip(),
                        "bytes": path.stat().st_size, "sha256_before": before, "sha256_after": after,
                        "wal_bytes": Path(str(path) + "-wal").stat().st_size if Path(str(path) + "-wal").exists() else 0,
                        "meta": metadata, "schema": schema,
                        "counts": {table: connection.execute("SELECT count(*) FROM " + table).fetchone()[0] for table in ("files", "nodes", "refs", "edges")}}
        (OUT / (name + "-store.json")).write_text(json.dumps({"identity": identity, "samples": rows}, indent=2))
        run["repositories"].append(identity)
        print(name, "targets", len(rows), "bound", sum(r["binding"]["status"] == "bound" for r in rows),
              "uncapped call sites", sum(len(r["edges"]) for r in rows), flush=True)
    (OUT / "run.json").write_text(json.dumps(run, indent=2))


if __name__ == "__main__":
    main()
