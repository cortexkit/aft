#!/usr/bin/env python3
"""Compare a fresh AFT-only Rust graph against the frozen compiler oracle.

Runs no third-party code: the probe checkout is only parsed by AFT. The native
incoming-edge query and caller normalization are the preserved study adapters.
"""
import asyncio
import importlib.util
import json
import hashlib
import re
import time
import os
from pathlib import Path
import sqlite3
import sys
from collections import Counter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from score import emitted, compare
from store_followup import bind_target, as_public_shape, CALLER_SQL

ROOT = Path.cwd()
BASE = ROOT / "target/rust-resolver-study"
ORACLE = json.loads((HERE / "probe-oracle.json").read_text())

def normalized_edges(answer):
    response = dict(answer.get("response", {}))
    response["callers"] = [dict(group, file=group["file"].removeprefix(str(BASE / "probe") + "/")) for group in response.get("callers", [])]
    edges = emitted({"response": response}, "aft", ORACLE["definitions"], "probe")[0]
    for edge in edges:
        edge["certain"] = edge["certain"] and edge["raw"].get("resolved_by") not in ("dispatch", "possible_target (dispatch)")
    return edges


def publication(state, corpus, views):
    if not views:
        pointers = list(state.glob("callgraph/*/*.current"))
        assert len(pointers) == 1, pointers
        pointer = pointers[0]
        filename = pointer.read_text().strip()
        assert Path(filename).name == filename and filename.endswith(".sqlite"), filename
        return pointer.parent / filename, {"pointer": str(pointer), "generation": filename}
    scope = hashlib.sha256(str(corpus.resolve()).encode()).hexdigest()[:16] + ".callgraph"
    members = []
    for ledger in state.glob("blobs/v3/*/members.sqlite"):
        connection = sqlite3.connect(ledger.as_uri() + "?mode=ro")
        row = connection.execute("SELECT root,view_dir FROM members WHERE scope=? AND kind='view' AND state='active'", (scope,)).fetchone()
        connection.close()
        if row:
            assert Path(os.fsdecode(row[0])) == corpus.resolve(), row
            directory = ledger.parent / "views" / scope
            assert Path(os.fsdecode(row[1])) == directory, row
            members.append((ledger, directory))
    assert len(members) == 1, members
    ledger, directory = members[0]
    pointer = directory / "pointer.sqlite"
    connection = sqlite3.connect(pointer.as_uri() + "?mode=ro")
    generation = connection.execute("SELECT generation FROM pointer WHERE singleton=1").fetchone()[0]
    connection.close()
    assert generation and Path(generation).name == generation, generation
    reference = directory / ("derived-" + generation + ".ref")
    owner = reference.read_text().strip() if reference.exists() else generation
    assert owner and Path(owner).name == owner, owner
    database = directory / ("derived-" + owner + ".sqlite")
    assert database.is_file(), database
    return database, {"ledger": str(ledger), "scope": scope, "pointer": str(pointer), "generation": generation, "owner": owner}


async def capture(label, binary, views=False, performance=False):
    state = BASE / (label + "-state")
    if state.exists():
        raise RuntimeError("Cold state already exists: " + str(state))
    state.mkdir(parents=True)
    corpus = BASE / "probe"
    env = dict(os.environ, AFT_STORAGE_DIR=str(state))
    for key in ("HOME", "XDG_CACHE_HOME", "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME"):
        path = state / key.lower()
        path.mkdir()
        env[key] = str(path)
    spec = importlib.util.spec_from_file_location("load_check", ROOT / "benchmarks/load-check/run.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    logdir = BASE / (label + "-logs")
    logdir.mkdir()
    timing = BASE / (label + "-time.txt")
    cold_start = time.monotonic()
    proc = await asyncio.create_subprocess_exec("/usr/bin/time", "-v", "-o", str(timing), str(binary), cwd=corpus, env=env,
        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, start_new_session=True)
    client = module.NDJSONClient(proc, logdir)
    readers = [asyncio.create_task(client.stdout()), asyncio.create_task(client.stderr())]
    responses = {}
    try:
        _, configured = await client.request({"command": "configure", "session_id": "rust-resolver-study", "project_root": str(corpus),
            "harness": "opencode", "storage_dir": str(state), "config": [{"tier": "user", "source": "<frozen-study>",
            "doc": json.dumps({"views": {"enabled": views}})}]}, 180)
        assert configured.get("success"), configured
        async def callers(target, query=None):
            return await client.request({"command": "tool_call", "session_id": "rust-resolver-study", "name": "callgraph",
                "arguments": {"op": "callers", "path": target["file"], "symbol": query or target["name"].rsplit("::", 1)[-1], "depth": 1, "includeTests": True}}, 180)
        for attempt in range(1200):
            _, answer = await callers(ORACLE["samples"][0])
            if answer.get("code") != "callgraph_building":
                assert answer.get("success"), answer
                break
            await asyncio.sleep(1)
        else:
            raise RuntimeError("Graph build timed out")
        cold_wall = time.monotonic() - cold_start
        for target in ([] if performance else ORACLE["samples"]):
            _, answer = await callers(target)
            if answer.get("code") == "ambiguous_symbol" and target.get("parent"):
                owner = target["parent"].removeprefix("impl ")
                candidates = re.search(r"candidates: \[(.*)\]", answer.get("message", ""))
                if candidates:
                    matches = [c.strip() for c in candidates.group(1).split(", ") if c.strip() == owner + "::" + target["name"].rsplit("::", 1)[-1]]
                    if len(matches) == 1:
                        _, answer = await callers(target, matches[0])
            responses[target["id"]] = answer
    finally:
        await client.close()
        await asyncio.gather(*readers, return_exceptions=True)
    assert not client.protocol_errors, client.protocol_errors
    assert proc.returncode == 0, proc.returncode
    process_time = timing.read_text()
    metrics = {"label": label, "views": views, "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(), "cold_wall_s": cold_wall,
        "user_cpu_s": float(re.search(r"User time \(seconds\): ([\d.]+)", process_time).group(1)),
        "system_cpu_s": float(re.search(r"System time \(seconds\): ([\d.]+)", process_time).group(1)),
        "peak_rss_kib": int(re.search(r"Maximum resident set size \(kbytes\): (\d+)", process_time).group(1)),
        "scope": "spawn, configure, cold graph build, initial ready caller query, and shutdown; no warm query batch" if performance else "includes the 150-query scoring session"}
    (BASE / (label + "-metrics.json")).write_text(json.dumps(metrics, indent=2))
    if performance:
        print(json.dumps(metrics, indent=2), flush=True)
        return metrics
    db, published = publication(state, corpus, views)
    database_hash = hashlib.sha256(db.read_bytes()).hexdigest()
    connection = sqlite3.connect(db.as_uri() + "?mode=ro")
    connection.row_factory = sqlite3.Row
    meta = dict(connection.execute("SELECT k,v FROM meta"))
    assert meta.get("ready") == "1", meta
    published.update(database=str(db), sha256=database_hash, meta=meta)
    selected = {d["id"] for d in ORACLE["samples"]}
    truth = {r["target"]["id"]: r for r in ORACLE["oracle_sets"] if r["complete"] and r["target"]["id"] in selected}
    result = {"publication": published, "views": views, "label": label, "targets": len(truth), "binary": str(binary), "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(), "oracle_sha256": hashlib.sha256((HERE / "probe-oracle.json").read_bytes()).hexdigest(), "samples": []}
    for ident, record in truth.items():
        target = record["target"]
        binding = bind_target(connection, target, (corpus / target["file"]).read_bytes(), responses[ident])
        edges = []
        for file, symbol in binding["tuples"]:
            edges.extend(dict(r) for r in connection.execute(CALLER_SQL, (file, symbol)))
        answer = as_public_shape(target, edges)
        predicted = normalized_edges(answer)
        result["samples"].append({"id": ident, "binding": binding, "edges": predicted, "public_response": responses[ident], "public_edges": normalized_edges({"response": responses[ident]}), "truth": record["calls"]})
    connection.close()
    assert hashlib.sha256(db.read_bytes()).hexdigest() == database_hash
    (BASE / (label + ".json")).write_text(json.dumps(result, indent=2))
    print(json.dumps(summarize(result), indent=2), flush=True)
    return result

def summarize(result):
    rows = []
    for certain in (False, True):
        for pairs in (True, False):
            counts = Counter()
            for sample in result["samples"]:
                edges = [e for e in sample["edges"] if not certain or e["certain"]]
                tp, fp, fn = compare(sample["truth"], edges, pairs)
                counts.update(tp=len(tp), fp=len(fp), fn=len(fn))
            tp, fp, fn = (counts[k] for k in ("tp", "fp", "fn"))
            rows.append({"mode": "certain" if certain else "all", "representation": "caller_pairs" if pairs else "mixed_sites",
                **counts, "precision": tp/(tp+fp) if tp+fp else None, "recall": tp/(tp+fn) if tp+fn else None})
    return {"label": result["label"], "targets": result["targets"], "dispatch_sites": sum(e["raw"].get("resolved_by") == "dispatch" for s in result["samples"] for e in s["edges"]), "bindings": dict(Counter(s["binding"]["status"] for s in result["samples"])), "rows": rows}

def comparison(before, after):
    before_by = {s["id"]: s for s in before["samples"]}
    deltas = {}
    for certain in (False, True):
        newly_found, newly_wrong, removed_true, removed_wrong = [], [], [], []
        for sample in after["samples"]:
            old = before_by[sample["id"]]
            truth = {e["caller"] for e in sample["truth"]}
            previous = {e["caller"] for e in old["edges"] if not certain or e["certain"]}
            current = {e["caller"] for e in sample["edges"] if not certain or e["certain"]}
            for caller in sorted(current - previous):
                (newly_found if caller in truth else newly_wrong).append([sample["id"], caller])
            for caller in sorted(previous - current):
                (removed_true if caller in truth else removed_wrong).append([sample["id"], caller])
        deltas["certain" if certain else "all"] = {"newly_found": newly_found, "newly_wrong": newly_wrong,
            "removed_true": removed_true, "removed_wrong": removed_wrong,
            "counts": {"newly_found": len(newly_found), "newly_wrong": len(newly_wrong), "removed_true": len(removed_true), "removed_wrong": len(removed_wrong)}}
    return {"before": summarize(before), "after": summarize(after), "deltas": deltas}


async def main():
    if sys.argv[1] == "--compare":
        before, after = (json.loads(Path(path).read_text()) for path in sys.argv[2:4])
        result = comparison(before, after)
        Path(sys.argv[4]).write_text(json.dumps(result, indent=2))
        print(json.dumps({"before": result["before"], "after": result["after"], "deltas": {mode: data["counts"] for mode, data in result["deltas"].items()}}, indent=2))
        return
    label = sys.argv[1]
    await capture(label, Path(sys.argv[2]).resolve(), "--views" in sys.argv, "--perf" in sys.argv)
    if label == "after":
        delta = comparison(json.loads((BASE / "main.json").read_text()), json.loads((BASE / "after.json").read_text()))
        (BASE / "comparison.json").write_text(json.dumps(delta, indent=2))
        print(json.dumps(delta, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
